const pool = require('../db');
const { mapNormalRow, mapFallEventRow } = require('../utils/mapRow');

const DEVICE_ID = process.env.DEVICE_ID || 'health_device';

// GET /api/sensor/latest
const getLatest = async (req, res) => {
  const device_id = req.query.device_id || DEVICE_ID;
  try {
    const result = await pool.query(
      `SELECT * FROM sensor_data
       WHERE device_id = $1
       ORDER BY timestamp DESC
       LIMIT 1`,
      [device_id]
    );
    if (result.rows.length === 0) return res.json(null);
    res.json(mapNormalRow(result.rows[0]));
  } catch (err) {
    console.error('[sensor/latest]', err.message);
    res.status(500).json({ message: 'Lỗi truy vấn dữ liệu.' });
  }
};

// GET /api/sensor/history?limit=100
const getHistory = async (req, res) => {
  const device_id = req.query.device_id || DEVICE_ID;
  const limit     = Math.min(parseInt(req.query.limit) || 100, 500);
  try {
    const result = await pool.query(
      `SELECT * FROM (
         SELECT * FROM sensor_data
         WHERE device_id = $1
         ORDER BY timestamp DESC
         LIMIT $2
       ) sub
       ORDER BY timestamp ASC`,
      [device_id, limit]
    );
    res.json(result.rows.map(mapNormalRow));
  } catch (err) {
    console.error('[sensor/history]', err.message);
    res.status(500).json({ message: 'Lỗi truy vấn lịch sử.' });
  }
};

// GET /api/sensor/fall-events
const getFallEvents = async (req, res) => {
  const device_id = req.query.device_id || DEVICE_ID;
  try {
    const result = await pool.query(
      `SELECT * FROM sensor_data
       WHERE device_id = $1
         AND event IN (1, 2)
       ORDER BY timestamp DESC
       LIMIT 20`,
      [device_id]
    );
    res.json(result.rows.map(mapFallEventRow));
  } catch (err) {
    console.error('[sensor/fall-events]', err.message);
    res.status(500).json({ message: 'Lỗi truy vấn sự kiện.' });
  }
};

// GET /api/sensor/latest-fall — dùng cho polling real-time
const getLatestFall = async (req, res) => {
  const device_id = req.query.device_id || DEVICE_ID;
  try {
    const result = await pool.query(
      `SELECT * FROM sensor_data
       WHERE device_id = $1
         AND event IN (1, 2)
       ORDER BY timestamp DESC
       LIMIT 1`,
      [device_id]
    );
    if (result.rows.length === 0) return res.json(null);
    res.json(mapFallEventRow(result.rows[0]));
  } catch (err) {
    console.error('[sensor/latest-fall]', err.message);
    res.status(500).json({ message: 'Lỗi truy vấn sự kiện.' });
  }
};

module.exports = { getLatest, getHistory, getFallEvents, getLatestFall };
