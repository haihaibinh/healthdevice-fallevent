const express = require('express');
const cors    = require('cors');
require('dotenv').config();

const deviceRoutes = require('./src/routes/device.routes');
const sensorRoutes = require('./src/routes/sensor.routes'); // nhớ đổi tên file

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Đăng ký routes
app.use('/api/device', deviceRoutes);
app.use('/api/sensor', sensorRoutes);

app.listen(PORT, () => {
  console.log(`🚀 Server đang chạy tại http://localhost:${PORT}`);
});