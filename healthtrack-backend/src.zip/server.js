const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

const pool = new Pool({
  host:     process.env.DB_HOST,
  port:     process.env.DB_PORT,
  database: process.env.DB_NAME,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

// ── Map tên cột DB → tên field frontend ──────────────────────
const mapRow = (row) => ({
  device_id:      row.device_id,
  timestamp:      Number(row.timestamp),
  battery_node1:  row.battery_node1,
  battery_node2:  row.battery_node2,
  emg_rms:        row.emg,
  acc_mag:        row.acceleration,
  tilt_angle:     row.angle,
  hr:             row.heart_rate,
  spo2:           row.spo2,
  hrv:            row.hrv,
  risk_score:     parseFloat(row.risk_score),
  activity_label: row.event === 1 ? 'fall' : 'standing',
});

// ── GET /api/sensor/latest?device_id=health_device ───────────
app.get('/api/sensor/latest', async (req, res) => {
  const { device_id = 'health_device' } = req.query;
  try {
    const result = await pool.query(
      `SELECT * FROM sensor_data
       WHERE device_id = $1
       ORDER BY timestamp DESC
       LIMIT 1`,
      [device_id]
    );
    if (result.rows.length === 0) return res.json(null);
    res.json(mapRow(result.rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'DB error' });
  }
});

// ── GET /api/sensor/history?device_id=health_device&limit=100 ─
app.get('/api/sensor/history', async (req, res) => {
  const { device_id = 'health_device', limit = 100 } = req.query;
  try {
    const result = await pool.query(
      `SELECT * FROM (
         SELECT * FROM sensor_data
         WHERE device_id = $1
         ORDER BY timestamp DESC
         LIMIT $2
       ) sub ORDER BY timestamp ASC`,
      [device_id, parseInt(limit)]
    );
    res.json(result.rows.map(mapRow));
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'DB error' });
  }
});

// ── GET /api/sensor/fall-events?device_id=health_device ──────
app.get('/api/sensor/fall-events', async (req, res) => {
  const { device_id = 'health_device' } = req.query;
  try {
    const result = await pool.query(
      `SELECT * FROM sensor_data
       WHERE device_id = $1 AND event = 1
       ORDER BY timestamp DESC
       LIMIT 20`,
      [device_id]
    );
    res.json(result.rows.map((row) => ({
      device_id:          row.device_id,
      event_id:           `evt_${row.id}`,
      event_type:         'fall',
      timestamp_start:    Number(row.timestamp),
      timestamp_peak:     Number(row.timestamp) + 3,
      timestamp_end:      Number(row.timestamp) + 6,
      risk_score:         parseFloat(row.risk_score),
      cause_hint:         'loss_of_balance',
      hr:                 row.heart_rate,
      spo2:               row.spo2,
      hrv:                row.hrv,
      emg_rms_peak:       row.emg,
      acc_mag_peak:       row.acceleration,
      tilt_angle_peak:    row.angle,
      posture_after_event:'on_ground',
      alert_triggered:    true,
    })));
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'DB error' });
  }
});

// ── GET /api/device ───────────────────────────────────────────
app.get('/api/device', async (req, res) => {
  res.json({
    id:         'health_device',
    name:       'HealthBand Pro',
    macAddress: 'AA:BB:CC:DD:EE:FF',
    status:     'CONNECTED',
    lastSeen:   new Date().toISOString(),
  });
});

app.listen(process.env.PORT, () => {
  console.log(`Backend running on http://localhost:${process.env.PORT}`);
});